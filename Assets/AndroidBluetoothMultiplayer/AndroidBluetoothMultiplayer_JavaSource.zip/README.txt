Android Bluetooth Multiplayer
=============================

The source project is an Android Studio project. Just open it in Android Studio and it should build as-is. Android SDK v25 and Android Studio 2.3 or newer are required.

There is an additional Prime31Integration project, used for better integration with Prime31's plugins.

Feel free to contact if you are having any troubles with building the project.

--
Lost Polygon
contact@lostpolygon.com